package juego;

import java.awt.*;
import entorno.*;

public class Cohete {
    
    private double x;
    private double y;
    private double angulo;
    
    //Imagenes del cohete
    private Image CoheteDerecha;
  

    //Condicionales para el disparo
   
    private boolean condicionAdelante;
    
    
    Cohete(double x, double y){

        this.x = x;
        this.y = y;
        CoheteDerecha = Herramientas.cargarImagen("juego/images/unknown.png");
        this.condicionAdelante = false; //cohete adelante
        

    }

    public void dibujarse(Entorno e, Mikasa mikasa) //Esto dibuja solo la imagen del cohete
	{
       
        posicionCohete(mikasa);
        e.dibujarImagen(CoheteDerecha, this.x, this.y, this.angulo, 0.1);
      

	}

    public boolean colisionCohete(Kyojin titan){


       if(Colisiones.colision(this.x, this.y, titan.getX(), titan.getY(), 35)){


            return true;
       }

       return false;

    }

    public double getX(){

        return this.x;


    }

    public double getY(){

        return this.y;


    }

    public void girar(double modificador) 
	{
		this.angulo = this.angulo + modificador;
		if(this.angulo < 0) {
			this.angulo +=2*Math.PI;
		}
        if(this.angulo > 2*Math.PI) {
        	this.angulo -=2*Math.PI;
        }
			
	}
    
    public void moverAdelante() {
		this.x += Math.cos(this.angulo)*5;
		this.y += Math.sin(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}
    public void posicionCohete(Mikasa mikasa){

        if(!this.condicionAdelante){

            this.condicionAdelante = true;
            this.angulo = mikasa.getAngle();
        }

        if(this.condicionAdelante){

            this.moverAdelante();

        }
        

    }

    /* 
    public void posicionCohete(Mikasa mikasa) {
        
            

            //Sirve para que el cohete dispare hacia la derecha
            if (mikasa.getX() > 400 && mikasa.getY() > 100 && mikasa.getY() < 500 && !this.condicionAbajoY  && !this.condicionAtras && !this.condicionAdelante && !this.condicionArribaY) {
                this.x--;
                this.condicionAtras = true;
            }

            //Sirve para que el cohete dispare hacia la izquierda
            if ( mikasa.getX() < 400 && mikasa.getY() > 100  && mikasa.getY() < 500 && !this.condicionAbajoY   && !this.condicionAdelante && !this.condicionAtras && !this.condicionArribaY) {
                this.x++;
                this.condicionAdelante = true;
            }

            //Sirve para que el cohete dispare hacia abajo
            if(mikasa.getY() < 100 && !this.condicionAdelante && !this.condicionAtras && !this.condicionAbajoY && !this.condicionArribaY){

                this.y++;
                this.condicionAbajoY = true;

            }

            //Sirve para que el cohete dispare hacia arriba
            if(mikasa.getY() > 500 && !this.condicionAdelante && !this.condicionAtras && !this.condicionAbajoY  && !this.condicionArribaY){

                this.y--;
                this.condicionArribaY = true;
            }
            

            //Deteccion de que direccion debe ir el cohete hasta que se elimine
            if(this.condicionAtras){
    
                this.x--;
    
            }
    
            if(this.condicionAdelante){
    
                this.x++;
    
            }

            if(this.condicionAbajoY){

                this.y++;
            }

            if(this.condicionArribaY){


                this.y--;
            }
            

        
            


        
        

    }   
*/
}
