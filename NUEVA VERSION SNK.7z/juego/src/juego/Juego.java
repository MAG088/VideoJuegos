package juego;

import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;

import java.awt.Color;
import java.lang.Math;

public class Juego extends InterfaceJuego {
	// El objeto Entorno que controla el tiempo y otros
	private Entorno e;

	Fondo Background; // Crea el fondo
	Mikasa mikasa; // Crea el personaje
	Pocion pocion; // Crea la pocion
	Kyojin[] titan; // Crear a los titanes
	int iterador; // Sirve para el tiempo de regeneracion de titanes
	Cohete cohete; // Establece el cohete de Mikasa
	boolean CoheteCondicion;
	int cantTitanesEliminados; // Indica la cantidad de titanes eliminados
	int iteradorSandia; //Sirve para regenerar las sandias
	Fruta sandia; //Sirve para agarrar mas vidas
	casa[] casas;
	int cantidadCohetes; // Indica la cantidad de cohetes del usuario
	boolean victoria;
	Corazoncitos corazones;
	// Variables y métodos propios de cada grupo
	// ...

	Juego() {
		// Inicializa el objeto entorno
		this.e = new Entorno(this, "Attack on Titan, Final Season - Grupo ... - v1", 800, 600);

		// Inicializar lo que haga falta para el juego
		// ...

		Background = new Fondo(); // Construye el fondo
		titan = new Kyojin[4]; // Construye a los titanes
		pocion = new Pocion(300, 100); // Establece la pocion
		sandia = new Fruta(500, 200);
		iterador = 0; // Sirve para la regeneracion del Kyojin
		iteradorSandia = 0;
		CoheteCondicion = false; // Sirve para que el cohete funcione y no se pueda tirar a cada momento
		cantidadCohetes = 0;
		casas = new casa[4];
		mikasa = new Mikasa(400, 300); // crea a mikasa
		cantidadCohetes = 4; //Determina la cantidad de cohetes iniciales
		generarTitanes(); // Coloca las posiciones de cada titan
		victoria = false; //Determina si Mikasa gana la partida
		corazones = new Corazoncitos();
		// Sonidos del juego
		Herramientas.cargarSonido("juego/Sounds/boom1.wav");
		Herramientas.cargarSonido("juego/Sounds/boom4.wav");
		Herramientas.cargarSonido("juego/Sounds/sound1.wav");
		

		casas[0] = new casa(600, 430); // crea una casa abajo a la derecha
		casas[1] = new casa(200, 430); // crea una casa abajo a la izquierda
		casas[2] = new casa(200, 165); // Crea una casa arriba a la izquierda
		casas[3] = new casa(600, 165); // crea una casa arriba a la derecha
		// Inicia el juego!
		this.e.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y
	 * por lo tanto es el método más importante de esta clase. Aquí se debe
	 * actualizar el estado interno del juego para simular el paso del tiempo
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick() {
		// Procesamiento de un instante de tiempo
		// ...

		if (mikasa != null && !victoria) { // Si mikasa no es null se ejecuta todo

			Background.dibujarse(e); // Dibuja al fondo
			dibujarCasas(); // Funcion que permite dibujar todas las casas
			mikasa.dibujarse(e); // Dibuja a Mikasa
			DibujarTitanes(); // Dibuja a los titanes
			pocion.dibujarPociones(e, mikasa, casas); // Dibuja a la pocion de acuerdo a mikasa
			mikasa.kyojina(pocion); // Permite que Mikasa sea Kyojina
			regenerarTitanes(); // Si hay titanes muertos los regenera cada 1000 iteraciones
			corazones.dibujarse(e,mikasa);
			regenerarSandias();
			if(sandia != null){

				sandia.dibujarse(e);; //Sirve para dibujar las sandias xd
				if(mikasa.obtenerVidas(sandia)){

					sandia = null;
				}


			}
			
			
			System.out.println("Vidas: " + mikasa.getLife());
			// Fuente que se muestra en el juego
			e.cambiarFont("Minecraft", 30, Color.black);
			e.escribirTexto("Cohetes: " + String.valueOf(this.cantidadCohetes), 620, 25);
			e.escribirTexto("Kills: " + String.valueOf(this.cantTitanesEliminados), 10, 25);

			for (int i = 0; i < casas.length; i++) {

				if (mikasa.colisionCasaMikasa(casas[i])) {// detecta que mikasa colisione con el objeto casa

					mikasa.posicionMikasaConLaCasa(casas[i]); // Permite que mikasa rebote si choca con la casa

				}

			}

			// Sirve para detectar que el usuario aprete la tecla
			if (e.estaPresionada(e.TECLA_ESPACIO) && !CoheteCondicion && cantidadCohetes != 0) {
				CoheteCondicion = true; // Para que el usuario no pueda lanzar enseguida otro cohete
				cohete = new Cohete(mikasa.getX(), mikasa.getY()); // Construye un cohete
				this.cantidadCohetes--;
			}

			if (cohete != null) {

				if (cohete.getX() >= 781 || cohete.getX() <= 20 || cohete.getY() >= 571 || cohete.getY() <= 29) { // Si toca la pantalla...

					CoheteCondicion = false; // Falso para que el jugador pueda lanzar otro
					cohete = null; // El cohete al tocar la pantalla se elimina

				}

				for (int i = 0; i < casas.length; i++) { // Deteccion de colision entre el cohete y la casa

					if (Colisiones.colision(cohete.getX(), cohete.getY(), casas[i].getX(), casas[i].getY(), 100)) {

						
						CoheteCondicion = false; // Falso para que el jugador pueda lanzar otro
						cohete = null; // El cohete al tocar la pantalla se elimina
						Herramientas.play("juego/Sounds/boom1.wav");
					}
 
				}

			}

			dibujarCohete(); // Dibuja el cohete en la pantalla y hace que despegue de Mikasa
			eliminarMikasaTitan(); // Elimina a Mikasa si no es Kyojina y mata al titan si lo es
			victoria(); //detecta si todos los titanes han sido eliminados

		}



		if (mikasa == null && !victoria) {

			e.dibujarTriangulo(0, 0, 1000, 1000, 0, Color.black);
			e.cambiarFont("Minecraft", 100, Color.white);
			e.escribirTexto("Game over", 120, 310);

		}

		if(victoria){

			e.dibujarTriangulo(0, 0, 1000, 1000, 0, Color.black);
			e.cambiarFont("Minecraft", 90, Color.white);
			e.escribirTexto("Gano profe cesar!!", 25, 310);

		}

		

	}

	private void victoria(){
		int cont = 0;
		for(int i = 0;i < titan.length; i++){

			
			if(titan[i] == null){

				cont++;
				
			}

		}

		if(cont == 4){

			this.victoria = true;
		}


	}
	private void regenerarTitanes() {

		iterador++; // Aumentar el iterador
		for (int i = 0; i < titan.length; i++) { // Reviso el arreglo de titanes

			if (iterador == 1000 && titan[i] == null) { // Si alguno fue eliminado

				generarTitanes(); // Regenerar los titanes caidos

			}

		}
		if (iterador == 1000) { // Reiniciar el iterador

			iterador = 0;
		}

	}

	// Genera los titanes en la pantalla y los dibuja
	private void generarTitanes() {

		for (int i = 0; i < titan.length; i++) { // Se generan 4 titanes en posiciones al azar

			if (titan[i] == null) { // Si en la posicion no hay titan...

				int PosAlX = (int) (Math.random() * 750) + 1; // Posicion aleatoria en X
				int PosAlY = (int) (Math.random() * 550) + 1; // Posicion aleatoria en Y

				// Permite que los titanes no se generen fuera de la pantalla
				// 30 es el limite de la pantalla en Horizontal y 35 es el limite de la pantalla
				// en Vertical
				while (PosAlX < 30 && PosAlY < 35
						|| Colisiones.colision(mikasa.getX(), mikasa.getY(), PosAlX, PosAlY, 100)) {
					PosAlX = (int) (Math.random() * 750) + 1;
					PosAlY = (int) (Math.random() * 550) + 1;
				}

				this.titan[i] = new Kyojin(PosAlX, PosAlY);

			}

		}

	}

	private void DibujarTitanes() {

		// Dibuja los titanes y persiguen a Mikasa

		for (int i = 0; i < titan.length; i++) { // Los cuatro titanes

			if (titan[i] != null) { // Si el titan no es null voy a ejecutar

				titan[i].dibujarse(e); // Dibujar al titan

				for (int j = 0; j < casas.length; j++) {

					if (!Colisiones.colision(titan[i].getX(), titan[i].getY(), casas[j].getX(), casas[j].getY(), 130)) {
						
						

							titan[i].cambiarAngulo(mikasa.getX(), mikasa.getY());
							titan[i].mover(); // Ejecucion para que persiga a Mikasa Si no sucede lo anterior


						
						
						//Funciones de implementacion, evita que los titanes se traben y mejora sustancialmente su movimiento
						if(mikasa.getY() > casas[0].getY() + 60 && titan[i].getY() < casas[0].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() > casas[1].getY() + 60 && titan[i].getY() < casas[1].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() < casas[2].getY() - 60 && titan[i].getY() > casas[2].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() < casas[3].getY() - 60 && titan[i].getY() > casas[3].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }


						
				
						

					}

					else {

						titan[i].colisionCasaTitan(casas[j]);

					}

				}

				for (int l = 0; l < titan.length; l++) { // Esto es para detectar colision entre titanes

					if (titan[l] != null && i != l) { // El titan en posicion l no debe ser null

						titan[i].deteccion(titan[l]); // Detecto si el titan de posicion i choca con otro
						titan[i].dibujarse(e); // Dibujo a ambos titanes para actualizar la pantalla
						titan[l].dibujarse(e); // Dibujo a ambos titanes para actualizar la pantalla

					}

				}

			}

		}

	}

	private void eliminarMikasaTitan() {

		boolean colisionoNkyojina = false; // Sirve para que no tire error mikasa con el null
		boolean colisionokyojina = false; // Idem
		int PosicionEliminado = 0;

		// Detecta si colisiono mikasa con cada uno de los titanes
		for (int i = 0; i < titan.length; i++) {

			if (titan[i] != null) { // Si el titan no es null analiza la colision

				// Si no es kyojina quiere decir que entonces el jugador muere
				if (Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(), titan[i].getY(), 50)
						&& !mikasa.getKyojina()) {

					colisionoNkyojina = true;

				}

				// Si es kyojina entonces el jugador mata al titan
				if (Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(), titan[i].getY(), 50)
						&& mikasa.getKyojina()) {

					colisionokyojina = true;
					PosicionEliminado = i; // Me llevo la posicion del titan eliminado

				}

			}

		}

		if(colisionoNkyojina &&  mikasa.getLife() != 0){

			mikasa.setLife();
			mikasa.Regenerar();
			Herramientas.play("juego/Sounds/sandia.wav");

		}

		if (colisionoNkyojina && mikasa.getLife() == 0) { // Si esto es true mikasa muere

			mikasa = null;

		}

		if (colisionokyojina) { // Si esto es true el titan muere

			titan[PosicionEliminado] = null;
			this.cantTitanesEliminados++;
			Herramientas.play("juego/Sounds/boom1.wav");
		}

	}

	private void dibujarCohete() {

		if (cohete != null) {

			Boolean desaparece = false;
			cohete.dibujarse(e, mikasa); // Dibuja al cohete

			for (int i = 0; i < titan.length; i++) {

				if (titan[i] != null) {

					Boolean matar = false;
					matar = cohete.colisionCohete(titan[i]);

					if (matar) {
						this.cantTitanesEliminados++;
						desaparece = true;
						titan[i] = null;
						Herramientas.play("juego/Sounds/boom1.wav");

					}

				}
			}

			if (desaparece) {

				CoheteCondicion = false;
				cohete = null;

			}

		}

	}

	private void dibujarCasas() {

		for (int i = 0; i < casas.length; i++) {

			casas[i].dibujarse(e); // Dibuja la casa

		}

	}

	private void regenerarSandias(){

		if(sandia == null){

			iteradorSandia++; 

		}

		if(iteradorSandia == 500){

			iteradorSandia = 0;

			int PosAlX = (int) (Math.random() * 750 + 1); // Posicion aleatoria en X
			int PosAlY = (int) (Math.random() * 550 + 1); // Posicion aleatoria en Y

			while (PosAlX < 30 || PosAlY < 35
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[0].getX(), casas[0].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[1].getX(), casas[1].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[2].getX(), casas[2].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[3].getX(), casas[3].getY(), 400) 
							|| PosAlX > 50 && PosAlY > 55 && Colisiones.colision(PosAlX, PosAlY, sandia.getX(), sandia.getY(), 20)) {

				PosAlX = (int) (Math.random() * 750) + 1;
				PosAlY = (int) (Math.random() * 550) + 1;

			}

	
			sandia = new Fruta(PosAlX, PosAlY);
		}

	}
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}
}
