package juego;

import java.awt.Image;

import entorno.Entorno;
import entorno.Herramientas;

public class Pocion {
	private double x;
	private double y;

	private double angulo;
	private Image img4;

	public Pocion(int x, int y) {
		this.x = x;
		this.y = y;
		img4 = Herramientas.cargarImagen("juego/images/pocion.png");
	}

	public double getX() {

		return this.x;
	}

	public double getY() {

		return this.y;
	}

	public void dibujarse(Entorno entorno) // Esto dibuja solo la imagen de la pocion
	{
		entorno.dibujarImagen(img4, this.x, this.y, this.angulo, 0.02);

	}

	// Esto es la implementacion del estado Kyojina de Mikasa
	public void dibujarPociones(Entorno entorno, Mikasa Mikasa, casa[] casas) {

		if (!Mikasa.getKyojina()) { // Si mikasa no es kyojina se dibuja

			this.dibujarse(entorno);

		}

		else if (Mikasa.getKyojina()) { // Si es Kyojina, se regenera y cambia de posicion en cierto tiempo

			int PosAlX = (int) (Math.random() * 750 + 1); // Posicion aleatoria en X
			int PosAlY = (int) (Math.random() * 550 + 1); // Posicion aleatoria en Y

			// Permite que la pocion no se generen fuera de la pantalla
			// Primero verifica que el x e y no esten fuera de la pantalla y luego que no
			// colisione con alguna de las casas
			while (PosAlX < 30 || PosAlY < 35
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[0].getX(), casas[0].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[1].getX(), casas[1].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[2].getX(), casas[2].getY(), 400)
					|| PosAlX > 50 && PosAlY > 55
							&& Colisiones.colision(PosAlX, PosAlY, casas[3].getX(), casas[3].getY(), 400)) {

				PosAlX = (int) (Math.random() * 750) + 1;
				PosAlY = (int) (Math.random() * 550) + 1;

			}

			this.x = PosAlX;
			this.y = PosAlY;

		}

	}

}
