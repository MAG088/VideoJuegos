package juego;

public class Colisiones {
    

    
    public static boolean colision(double x1, double y1, double x2, double y2, double dist) {
		return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2) < dist * dist;
	}

	public static double cambiarTrayectoria(double angulo) {
		angulo += Math.PI/2;
		return angulo;
	}

	public static double cambiarAngulo(Double angulo) {
        angulo +=0.02;
		return angulo;
    }
}
