package juego;

import java.awt.*;
import entorno.*;

public class Kyojin {
	
	private double x;
	private double y;
	private Image img3; 
	private double angulo;
	

	public Kyojin(int x, int y) 
	{
		this.x = x;
		this.y = y;
		this.angulo = 0;
		img3 = Herramientas.cargarImagen("juego/images/titan.png");
		
	}
	
	public double getX(){

		return this.x;

	}

	public double getY(){

		return this.y;
	}

	public double getAngulo(){

		return this.angulo;
	}

	public void setAngulo(double angulo){

		this.angulo = angulo;


	}

	public void setX(double x){

		this.x = this.x - x;

	}
	
	public void dibujarse(Entorno e)
	{
		e.dibujarImagen(img3, this.x, this.y, 0, 0.275);
		

	}
	
	//El Titan persigue a Mikasa
	public void titanPersigue(Mikasa pj){	
		

		if(this.y < pj.getY()){ // Si la posicion de Mikasa es mayor en Y
						

			this.y += 0.3;
					
					
	
		}
		

		if(this.y > pj.getY()){ // Si la posicion de Mikasa es menor en Y

			this.y -= 0.3;
		
		
		}
		
			

		if(pj.getX() > this.x){  // Si la posicion de Mikasa es mayor en X

			this.x += 0.3;
		
		}

				

		if(pj.getX() < this.x){ // Si la posicion de Mikasa es menor en X

			this.x -= 0.3;
		
		}
		
		

	}
	

	public void deteccion(Kyojin titan2){ //Detecta si un titan colisiona con otro

		if(Colisiones.colision(this.x, this.y, titan2.getX(), titan2.getY(), 100)){

			if(this.x > titan2.x){

				this.x += 0.5;
				titan2.x -= 0.5;
				
			}
			else{

				this.x -= 0.5;
				titan2.x += 0.5;


			}

			if(this.y > titan2.getY()){

				this.y += 0.5;
				titan2.y -= 0.5;

			}
			else{

				this.y -= 0.5;
				titan2.y += 0.5;
			}



		}

		
		


	}

	public void cambiarAngulo(double x2, double y2){
		this.angulo = Math.atan2(y2 - this.y, x2 - this.x);
	}
	
	public void mover() {
		

			this.x += Math.cos(this.angulo)*0.2;
			this.y += Math.sin(this.angulo)*0.2;
		
		
		
	}
	
	public void titancentrar(){

		
		
			

		if(400 > this.x){  // Si la posicion de Mikasa es mayor en X

			this.x += 0.1;
		
		}

				

		if(400 < this.x){ // Si la posicion de Mikasa es menor en X

			this.x -= 0.1;
		
		}

	}
	public void colisionCasaTitan(casa casa){

		  
		


			if(this.y > casa.getY()){ //El titan esta debajo de la casa

				this.y += 5;
				


			}
			else{ //El titan esta por encima de la casa

				this.y -= 5;

			}

			if(this.x > casa.getX()){ // El titan esta del lado derecho de la casa

				this.x += 0.5;

                                                                                                            
			}
			else{ //El titan esta del lado izquierdo de la casa


				this.x -= 0.5;


			}
		

    }

	
}



	
