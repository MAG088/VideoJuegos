package juego;

import java.awt.*;
import entorno.Entorno;
import entorno.Herramientas;
public class Corazoncitos {
    
    private double x;
    private double y;
    private Image corazon1;
    private Image corazon2;
    private Image corazon3;

    public Corazoncitos(){

        this.x = 50;
        this.y = 570;
        corazon1 = Herramientas.cargarImagen("juego/Images/Corazones/corazones1.png");
        corazon2 = Herramientas.cargarImagen("juego/Images/Corazones/corazones2.png");
        corazon3 = Herramientas.cargarImagen("juego/Images/Corazones/corazones3.png");
    }

    void dibujarse(Entorno e, Mikasa mikasa){

        if(mikasa.getLife() == 3){

            e.dibujarImagen(corazon3, this.x, this.y, 0,0.1);

        }

        if(mikasa.getLife() == 2){

            e.dibujarImagen(corazon2, this.x, this.y, 0,0.1);   
        }

        if(mikasa.getLife() == 1){

            e.dibujarImagen(corazon1, this.x, this.y, 0,0.1); 

        }
        
    }

}
