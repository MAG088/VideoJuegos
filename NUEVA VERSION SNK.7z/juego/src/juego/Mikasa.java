package juego;

import java.awt.*;
import entorno.Entorno;
import entorno.Herramientas;

public class Mikasa {
	// Variables de instancia
	private double x; //El valor en x de la pantalla 
	private double y; //El valor en y de la pantalla 
	private double angulo; //El angulo de Mikasa
	private boolean Kyojina; //Modo kyojina
	private int iterador = 0; //Sirve para ver por cuanto tiempo esta en modo Kyojina
	private int vidas;
	//Imagenes de Mikasa
	private Image imgkyojina;
	private Image imgmikasa;
	private boolean colisionan; // Sirve para detectar la colision entre la casa y Mikasa

	

	public Mikasa(int x, int y) {
		this.x = x; //Establecer el x
		this.y = y; //Establecer el y
		imgkyojina = Herramientas.cargarImagen("juego/images/mikasa/kyojina.png");
		imgmikasa = Herramientas.cargarImagen("juego/images/mikasa/mikasa.png");
		this.Kyojina = false; //Mikasa al principio no es Kyojina
		this.angulo = 30;
		this.vidas = 3;
		Herramientas.cargarSonido("juego/Sounds/sandia.wav");
	}

	public boolean getColisiona() {

		return this.colisionan;
	}

	public void setColisiona() {

		this.colisionan = false;

	}

	public void Regenerar(){

		if(this.x >= 450){

			this.x = 100;
			this.y = 100;

		}
		else{

			this.x = 650;
			this.y = 550;
		}
		
	}

	public boolean getKyojina() {
		return this.Kyojina;
	}

	// Establece a Mikasa Como no KYojina
	public void setKyojina() {

		this.Kyojina = false;

	}

	public double getX() {

		return this.x;
	}

	public double getY() {

		return this.y;
	}

	public double getAngle(){

		return this.angulo;
	}

	public void setLife(){

		this.vidas--; 
	}

	public int getLife(){

		return this.vidas;

	}

	public void dibujarse(Entorno e) {

		this.movimiento(e); // El movimiento de Mikasa implementado
		if (this.Kyojina == true) {
			e.dibujarImagen(imgkyojina, this.x, this.y, this.angulo, 0.3);
		} else {
			e.dibujarImagen(imgmikasa, this.x, this.y, this.angulo, 0.3);
		}

	}

	// Esta es la funcion que detecta la colision con mikasa de la pocion pero se
	// necesita de la colision
	public void kyojina(Pocion pocion) {

		if (!this.getKyojina()) {

			if (Colisiones.colision(this.x, this.y, pocion.getX(), pocion.getY(), 25)) {

				this.Kyojina = true;
				this.iterador = 0;
				Herramientas.play("juego/Sounds/sound1.wav");
				System.out.println("Es kyojina!!");
			}

		}

		this.iterador++;

		if (this.iterador == 200) {

			this.iterador = 0;
		}

		if (this.iterador == 199 && this.getKyojina()) {

			this.Kyojina = false;

		}

	}

	public void moverIzquierda() {
		this.x -= Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}
	 
	public void moverDerecha() {
		this.x += Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void moverArriba() {
		this.x += Math.cos(this.angulo)*5;
		this.y += Math.sin(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void moverAbajo() {
		this.x -= Math.cos(this.angulo)*5;
		this.y -= Math.sin(this.angulo) * 5;
		
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void girar(double modificador) 
	{
		this.angulo = this.angulo + modificador;
		if(this.angulo < 0) {
			this.angulo +=2*Math.PI;
		}
        if(this.angulo > 2*Math.PI) {
        	this.angulo -=2*Math.PI;
        }
			
	}

	// Permite el movimiento de Mikasa
	public void movimiento(Entorno e) { // Permite unir los movimientos de mikasa en uno solo

		// Si presiona la tecla derecha se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_DERECHA) && this.x != 780) { // 780 es el maximo valor de la pantalla a la derecha
			this.girar(Herramientas.radianes(1));
		}

		// Si presiona la tecla izquierda se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_IZQUIERDA) && this.x != 20) { // 20 es el maximo valor de la pantalla a la
																	// izquierda
			this.girar(Herramientas.radianes(-1));;
		}
		 
		// Si presiona la tecla abajo se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_ABAJO) && this.y <= 570 && this.y >= 30 && this.x >= 27 && this.x <= 770) { // 570 es el maximo valor de la pantalla abajo
			this.moverAbajo();
		}

		// Si presiona la tecla arriba se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_ARRIBA) && this.y >= 30 && this.y <= 570 && this.x >= 27 && this.x <= 770) { // 30 es el maximo valor de la pantalla arriba
			this.moverArriba();
		}

		if(this.y >= 560){

			this.y -= 2;
		}

		if(this.y <= 30){

			this.y+=2;
		}

		if(this.x <= 27){

			this.x += 2;

		}

		if(this.x >= 760){

			this.x -= 2;
		}

	}

	public boolean colisionCasaMikasa(casa casa) {

		if (Colisiones.colision(this.x, this.y, casa.getX(), casa.getY(), 120)) {
			colisionan = true;
			//System.out.println("colisionan");
			return colisionan;
		} else {
			//System.out.println("no colisionan");
			colisionan = false;
			return colisionan;
		}
	}

	public void posicionMikasaConLaCasa(casa casa) {

		if (this.x >= casa.getX() && this.x != 780) { // Mikasa esta del lado derecho de la casa

			this.x += 5;
			//this.moverDerecha();
			// No se puede mover a la izquierda

		}

		if (this.x <= casa.getX() && this.x != 20) {

			this.x -= 5;
			//this.moverIzquierda();
			// No se puede mover a la derecha

		}

		if (this.y >= casa.getY() && this.y != 570) {

			this.y += 5;
			//this.moverAbajo();

			// No se puede mover hacia arriba

		}

		if (this.y < casa.getY() && this.y != 30) {

			this.y -= 5;
			//this.moverArriba();
			// No se puede mover hacia abajo
		}

	}

	public boolean obtenerVidas(Fruta sandia){

        if(Colisiones.colision(this.x, this.y, sandia.getX(), sandia.getY(), 30) && this.vidas < 3){

			
			this.vidas++;
			Herramientas.play("juego/Sounds/sandia.wav");
			return true;
			
		}
		return false;

    }

	/*
			
	
			
	
			
	
			
	
	*/

	// Vamos que podemos lograrlo !!
}
