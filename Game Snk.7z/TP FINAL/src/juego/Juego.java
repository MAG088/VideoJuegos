package juego;

import entorno.Entorno;
import entorno.Herramientas;
import entorno.InterfaceJuego;

import java.awt.Color;
import java.lang.Math;

public class Juego extends InterfaceJuego {
	// El objeto Entorno que controla el tiempo y otros
	private Entorno e;

	Fondo Background; // Crea el fondo
	Mikasa mikasa; // Crea el personaje
	Pocion pocion; // Crea la pocion
	Kyojin[] titan; // Crear a los titanes
	int iterador; // Sirve para el tiempo de regeneracion de titanes
	Cohete cohete; // Establece el cohete de Mikasa
	boolean CoheteCondicion;
	int cantTitanesEliminados; // Indica la cantidad de titanes eliminados

	casa[] casas;
	int cantidadCohetes; // Indica la cantidad de cohetes del usuario
	// Variables y métodos propios de cada grupo
	// ...

	Juego() {
		// Inicializa el objeto entorno
		this.e = new Entorno(this, "Attack on Titan, Final Season - Grupo ... - v1", 800, 600);

		// Inicializar lo que haga falta para el juego
		// ...

		Background = new Fondo(); // Construye el fondo
		titan = new Kyojin[4]; // Construye a los titanes
		pocion = new Pocion(300, 100); // Establece la pocion
		iterador = 0; // Sirve para la regeneracion del Kyojin
		CoheteCondicion = false; // Sirve para que el cohete funcione y no se pueda tirar a cada momento
		cantidadCohetes = 0;
		casas = new casa[4];
		mikasa = new Mikasa(400, 300); // crea a mikasa
		cantidadCohetes = 4;
		generarTitanes(); // Coloca las posiciones de cada titan

		// Sonidos del juego
		Herramientas.cargarSonido("juego/Sounds/boom1.wav");
		Herramientas.cargarSonido("juego/Sounds/boom4.wav");
		Herramientas.cargarSonido("juego/Sounds/sound1.wav");

		casas[0] = new casa(600, 430); // crea una casa abajo a la derecha
		casas[1] = new casa(200, 430); // crea una casa abajo a la izquierda
		casas[2] = new casa(200, 165); // Crea una casa arriba a la izquierda
		casas[3] = new casa(600, 165); // crea una casa arriba a la derecha
		// Inicia el juego!
		this.e.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y
	 * por lo tanto es el método más importante de esta clase. Aquí se debe
	 * actualizar el estado interno del juego para simular el paso del tiempo
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick() {
		// Procesamiento de un instante de tiempo
		// ...

		if (mikasa != null) { // Si mikasa no es null se ejecuta todo

			Background.dibujarse(e); // Dibuja al fondo
			dibujarCasas(); // Funcion que permite dibujar todas las casas
			mikasa.dibujarse(e); // Dibuja a Mikasa
			DibujarTitanes(); // Dibuja a los titanes
			pocion.dibujarPociones(e, mikasa, casas); // Dibuja a la pocion de acuerdo a mikasa
			mikasa.kyojina(pocion); // Permite que Mikasa sea Kyojina
			regenerarTitanes(); // Si hay titanes muertos los regenera cada 1000 iteraciones

			// Fuente que se muestra en el juego
			e.cambiarFont("Minecraft", 30, Color.black);
			e.escribirTexto("Cohetes: " + String.valueOf(this.cantidadCohetes), 620, 25);
			e.escribirTexto("Kills: " + String.valueOf(this.cantTitanesEliminados), 10, 25);

			for (int i = 0; i < casas.length; i++) {

				if (mikasa.colisionCasaMikasa(casas[i])) {// detecta que mikasa colisione con el objeto casa

					mikasa.posicionMikasaConLaCasa(casas[i]); // Permite que mikasa rebote si choca con la casa

				}

			}

			// Sirve para detectar que el usuario aprete la tecla
			if (e.estaPresionada(e.TECLA_ESPACIO) && !CoheteCondicion && cantidadCohetes != 0) {
				CoheteCondicion = true; // Para que el usuario no pueda lanzar enseguida otro cohete
				cohete = new Cohete(mikasa.getX(), mikasa.getY()); // Construye un cohete
				this.cantidadCohetes--;
			}

			if (cohete != null) {

				if (cohete.getX() == 781 || cohete.getX() == 5 || cohete.getY() == 571 || cohete.getY() == 29) { // Si toca la pantalla...

					CoheteCondicion = false; // Falso para que el jugador pueda lanzar otro
					cohete = null; // El cohete al tocar la pantalla se elimina

				}

				for (int i = 0; i < casas.length; i++) { // Deteccion de colision entre el cohete y la casa

					if (Colisiones.colision(cohete.getX(), cohete.getY(), casas[i].getX(), casas[i].getY(), 100)) {

						CoheteCondicion = false; // Falso para que el jugador pueda lanzar otro
						cohete = null; // El cohete al tocar la pantalla se elimina
					}

				}

			}

			dibujarCohete(); // Dibuja el cohete en la pantalla y hace que despegue de Mikasa
			eliminarMikasaTitan(); // Elimina a Mikasa si no es Kyojina y mata al titan si lo es

		}

		if (mikasa == null) {

			e.dibujarTriangulo(0, 0, 1000, 1000, 0, Color.black);
			e.cambiarFont("Minecraft", 100, Color.white);
			e.escribirTexto("Game over", 120, 310);

		}

	}

	private void regenerarTitanes() {

		iterador++; // Aumentar el iterador
		for (int i = 0; i < titan.length; i++) { // Reviso el arreglo de titanes

			if (iterador == 1000 && titan[i] == null) { // Si alguno fue eliminado

				generarTitanes(); // Regenerar los titanes caidos

			}

		}
		if (iterador == 1000) { // Reiniciar el iterador

			iterador = 0;
		}

	}

	// Genera los titanes en la pantalla y los dibuja
	private void generarTitanes() {

		for (int i = 0; i < titan.length; i++) { // Se generan 4 titanes en posiciones al azar

			if (titan[i] == null) { // Si en la posicion no hay titan...

				int PosAlX = (int) (Math.random() * 750) + 1; // Posicion aleatoria en X
				int PosAlY = (int) (Math.random() * 550) + 1; // Posicion aleatoria en Y

				// Permite que los titanes no se generen fuera de la pantalla
				// 30 es el limite de la pantalla en Horizontal y 35 es el limite de la pantalla
				// en Vertical
				while (PosAlX < 30 && PosAlY < 35
						|| Colisiones.colision(mikasa.getX(), mikasa.getY(), PosAlX, PosAlY, 100)) {
					PosAlX = (int) (Math.random() * 750) + 1;
					PosAlY = (int) (Math.random() * 550) + 1;
				}

				this.titan[i] = new Kyojin(PosAlX, PosAlY);

			}

		}

	}

	private void DibujarTitanes() {

		// Dibuja los titanes y persiguen a Mikasa

		for (int i = 0; i < titan.length; i++) { // Los cuatro titanes

			if (titan[i] != null) { // Si el titan no es null voy a ejecutar

				titan[i].dibujarse(e); // Dibujar al titan

				for (int j = 0; j < casas.length; j++) {

					if (!Colisiones.colision(titan[i].getX(), titan[i].getY(), casas[j].getX(), casas[j].getY(), 130)) {
						
						

							titan[i].cambiarAngulo(mikasa.getX(), mikasa.getY());
							titan[i].mover(); // Ejecucion para que persiga a Mikasa Si no sucede lo anterior


						
						
						//Funciones de implementacion, evita que los titanes se traben y mejora sustancialmente su movimiento
						if(mikasa.getY() > casas[0].getY() + 60 && titan[i].getY() < casas[0].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() > casas[1].getY() + 60 && titan[i].getY() < casas[1].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() < casas[2].getY() - 60 && titan[i].getY() > casas[2].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }

						 if(mikasa.getY() < casas[3].getY() - 60 && titan[i].getY() > casas[3].getY() && !Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(),titan[i].getY(), 270)){

							titan[i].titancentrar();
							//Si mikasa esta por debajo de la casa y el titan por arriba
							
						 }


						
				
						

					}

					else {

						titan[i].colisionCasaTitan(casas[j]);

					}

				}

				for (int l = 0; l < titan.length; l++) { // Esto es para detectar colision entre titanes

					if (titan[l] != null && i != l) { // El titan en posicion l no debe ser null

						titan[i].deteccion(titan[l]); // Detecto si el titan de posicion i choca con otro
						titan[i].dibujarse(e); // Dibujo a ambos titanes para actualizar la pantalla
						titan[l].dibujarse(e); // Dibujo a ambos titanes para actualizar la pantalla

					}

				}

			}

		}

	}

	private void eliminarMikasaTitan() {

		boolean colisionoNkyojina = false; // Sirve para que no tire error mikasa con el null
		boolean colisionokyojina = false; // Idem
		int PosicionEliminado = 0;

		// Detecta si colisiono mikasa con cada uno de los titanes
		for (int i = 0; i < titan.length; i++) {

			if (titan[i] != null) { // Si el titan no es null analiza la colision

				// Si no es kyojina quiere decir que entonces el jugador muere
				if (Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(), titan[i].getY(), 50)
						&& !mikasa.getKyojina()) {

					colisionoNkyojina = true;

				}

				// Si es kyojina entonces el jugador mata al titan
				if (Colisiones.colision(mikasa.getX(), mikasa.getY(), titan[i].getX(), titan[i].getY(), 50)
						&& mikasa.getKyojina()) {

					colisionokyojina = true;
					PosicionEliminado = i; // Me llevo la posicion del titan eliminado

				}

			}

		}

		if (colisionoNkyojina) { // Si esto es true mikasa muere

			mikasa = null;

		}

		if (colisionokyojina) { // Si esto es true el titan muere

			titan[PosicionEliminado] = null;
			this.cantTitanesEliminados++;
			Herramientas.play("juego/Sounds/boom1.wav");
		}

	}

	private void dibujarCohete() {

		if (cohete != null) {

			Boolean desaparece = false;
			cohete.dibujarse(e, mikasa); // Dibuja al cohete

			for (int i = 0; i < titan.length; i++) {

				if (titan[i] != null) {

					Boolean matar = false;
					matar = cohete.colisionCohete(titan[i]);

					if (matar) {
						this.cantTitanesEliminados++;
						desaparece = true;
						titan[i] = null;
						Herramientas.play("juego/Sounds/boom1.wav");

					}

				}
			}

			if (desaparece) {

				CoheteCondicion = false;
				cohete = null;

			}

		}

	}

	private void dibujarCasas() {

		for (int i = 0; i < casas.length; i++) {

			casas[i].dibujarse(e); // Dibuja la casa

		}

	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}
}
