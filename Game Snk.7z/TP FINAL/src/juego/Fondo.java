package juego;
import java.awt.*;
import entorno.*;

public class Fondo {
    
    private Image Fondo;
    public Fondo (){

        this.Fondo = Herramientas.cargarImagen("juego/images/fondo.png");
        
    }

    public Image getImage(){

        return this.Fondo;
    }

    public void dibujarse(Entorno e){

        e.dibujarImagen(Fondo, 400, 300, 0, 1);

    }
}
