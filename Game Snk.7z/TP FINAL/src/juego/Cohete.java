package juego;

import java.awt.*;
import entorno.*;

public class Cohete {
    
    private double x;
    private double y;
    
    //Imagenes del cohete
    private Image CoheteDerecha;
    private Image Coheteizquierda;
    private Image Coheteabajo;
    private Image CoheteArriba;

    //Condicionales para el disparo
    private boolean condicionAtras;
    private boolean condicionAdelante;
    private boolean condicionAbajoY;
    private boolean condicionArribaY;
    
    Cohete(double x, double y){

        this.x = x;
        this.y = y;
        CoheteDerecha = Herramientas.cargarImagen("juego/images/unknown.png");
        Coheteizquierda= Herramientas.cargarImagen("juego/images/cohete/derecha.png");
        Coheteabajo =  Herramientas.cargarImagen("juego/images/cohete/abajo.png");
        CoheteArriba = Herramientas.cargarImagen("juego/images/cohete/ARRIBA.png");
        this.condicionAtras = false; //cohete atras
        this.condicionAdelante = false; //cohete adelante
        this.condicionAbajoY = false; //Cohete abajo
        this.condicionArribaY = false; //Cohete arriba

    }

    public void dibujarse(Entorno e, Mikasa mikasa) //Esto dibuja solo la imagen del cohete
	{
       
        posicionCohete(mikasa);
       if(this.condicionAtras){

            e.dibujarImagen(Coheteizquierda, this.x, this.y, 0, 0.1);

       }
       if(this.condicionAdelante){

            e.dibujarImagen(CoheteDerecha, this.x, this.y, 0, 0.1);
       }

       if(this.condicionAbajoY){

            e.dibujarImagen(Coheteabajo, this.x, this.y, 0, 0.1);
       }

       if(this.condicionArribaY){

            e.dibujarImagen(CoheteArriba, this.x, this.y, 0, 0.1);

       }
        
       

	}

    public boolean colisionCohete(Kyojin titan){


       if(Colisiones.colision(this.x, this.y, titan.getX(), titan.getY(), 35)){


            return true;
       }

       return false;

    }

    public double getX(){

        return this.x;


    }

    public double getY(){

        return this.y;


    }
    
    public void posicionCohete(Mikasa mikasa) {
        
            

            //Sirve para que el cohete dispare hacia la derecha
            if (mikasa.getX() > 400 && mikasa.getY() > 100 && mikasa.getY() < 500 && !this.condicionAbajoY  && !this.condicionAtras && !this.condicionAdelante && !this.condicionArribaY) {
                this.x--;
                this.condicionAtras = true;
            }

            //Sirve para que el cohete dispare hacia la izquierda
            if ( mikasa.getX() < 400 && mikasa.getY() > 100  && mikasa.getY() < 500 && !this.condicionAbajoY   && !this.condicionAdelante && !this.condicionAtras && !this.condicionArribaY) {
                this.x++;
                this.condicionAdelante = true;
            }

            //Sirve para que el cohete dispare hacia abajo
            if(mikasa.getY() < 100 && !this.condicionAdelante && !this.condicionAtras && !this.condicionAbajoY && !this.condicionArribaY){

                this.y++;
                this.condicionAbajoY = true;

            }

            //Sirve para que el cohete dispare hacia arriba
            if(mikasa.getY() > 500 && !this.condicionAdelante && !this.condicionAtras && !this.condicionAbajoY  && !this.condicionArribaY){

                this.y--;
                this.condicionArribaY = true;
            }
            

            //Deteccion de que direccion debe ir el cohete hasta que se elimine
            if(this.condicionAtras){
    
                this.x--;
    
            }
    
            if(this.condicionAdelante){
    
                this.x++;
    
            }

            if(this.condicionAbajoY){

                this.y++;
            }

            if(this.condicionArribaY){


                this.y--;
            }
            

        
            


        
        

    }   

}
