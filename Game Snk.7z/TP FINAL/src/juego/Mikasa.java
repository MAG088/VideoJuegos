package juego;

import java.awt.*;
import entorno.Entorno;
import entorno.Herramientas;

public class Mikasa {
	// Variables de instancia
	private double x; //El valor en x de la pantalla 
	private double y; //El valor en y de la pantalla 
	private double angulo; //El angulo de Mikasa
	private boolean Kyojina; //Modo kyojina

	private int iterador = 0; //Sirve para ver por cuanto tiempo esta en modo Kyojina
	
	//Imagenes de Mikasa
	private Image imgkyojina;
	private Image imgmikasa;
	private boolean colisionan; // Sirve para detectar la colision entre la casa y Mikasa

	public Mikasa(int x, int y) {
		this.x = x; //Establecer el x
		this.y = y; //Establecer el y
		imgkyojina = Herramientas.cargarImagen("juego/images/mikasa/kyojina.png");
		imgmikasa = Herramientas.cargarImagen("juego/images/mikasa/mikasa.png");
		this.Kyojina = false; //Mikasa al principio no es Kyojina

	}

	public boolean getColisiona() {

		return this.colisionan;
	}

	public void setColisiona() {

		this.colisionan = false;

	}

	public boolean getKyojina() {
		return this.Kyojina;
	}

	// Establece a Mikasa Como no KYojina
	public void setKyojina() {

		this.Kyojina = false;

	}

	public double getX() {

		return this.x;
	}

	public double getY() {

		return this.y;
	}

	public void dibujarse(Entorno e) {

		this.movimiento(e); // El movimiento de Mikasa implementado
		if (this.Kyojina == true) {
			e.dibujarImagen(imgkyojina, this.x, this.y, this.angulo, 0.3);
		} else {
			e.dibujarImagen(imgmikasa, this.x, this.y, this.angulo, 0.3);
		}

	}

	// Esta es la funcion que detecta la colision con mikasa de la pocion pero se
	// necesita de la colision
	public void kyojina(Pocion pocion) {

		if (!this.getKyojina()) {

			if (Colisiones.colision(this.x, this.y, pocion.getX(), pocion.getY(), 25)) {

				this.Kyojina = true;
				this.iterador = 0;
				Herramientas.play("juego/Sounds/sound1.wav");
				System.out.println("Es kyojina!!");
			}

		}

		this.iterador++;

		if (this.iterador == 200) {

			this.iterador = 0;
		}

		if (this.iterador == 199 && this.getKyojina()) {

			this.Kyojina = false;

		}

	}

	public void moverIzquierda() {
		this.x -= Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void moverDerecha() {
		this.x += Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void moverArriba() {
		this.y -= Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	public void moverAbajo() {
		this.y += Math.cos(this.angulo) * 5;
		if (this.x > 900) {
			this.x = -100;
		}
		if (this.x < -100) {
			this.x = 900;
		}
		if (this.y > 650) {
			this.y = -50;
		}
		if (this.y < -50) {
			this.y = 650;
		}
	}

	// Permite el movimiento de Mikasa
	public void movimiento(Entorno e) { // Permite unir los movimientos de mikasa en uno solo

		// Si presiona la tecla derecha se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_DERECHA) && this.x != 780) { // 780 es el maximo valor de la pantalla a la derecha
			this.moverDerecha();
		}

		// Si presiona la tecla izquierda se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_IZQUIERDA) && this.x != 20) { // 20 es el maximo valor de la pantalla a la
																	// izquierda
			this.moverIzquierda();
		}

		// Si presiona la tecla abajo se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_ABAJO) && this.y != 570) { // 570 es el maximo valor de la pantalla abajo
			this.moverAbajo();
		}

		// Si presiona la tecla arriba se mueve hacia esa direccion
		if (e.estaPresionada(e.TECLA_ARRIBA) && this.y != 30) { // 30 es el maximo valor de la pantalla arriba
			this.moverArriba();
		}

	}

	public boolean colisionCasaMikasa(casa casa) {

		if (Colisiones.colision(this.x, this.y, casa.getX(), casa.getY(), 120)) {
			colisionan = true;
			System.out.println("colisionan");
			return colisionan;
		} else {
			System.out.println("no colisionan");
			colisionan = false;
			return colisionan;
		}
	}

	public void posicionMikasaConLaCasa(casa casa) {

		if (this.x > casa.getX() && this.x != 780) { // Mikasa esta del lado derecho de la casa

			this.moverDerecha();
			// No se puede mover a la izquierda

		}

		if (this.x < casa.getX() && this.x != 20) {

			this.moverIzquierda();
			// No se puede mover a la derecha

		}

		if (this.y > casa.getY() && this.y != 570) {

			this.moverAbajo();

			// No se puede mover hacia arriba

		}

		if (this.y < casa.getY() && this.y != 30) {

			this.moverArriba();
			// No se puede mover hacia abajo
		}

	}

	/*
			
	
			
	
			
	
			
	
	*/

	// Vamos que podemos lograrlo !!
}
