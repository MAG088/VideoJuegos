package juego;

import java.awt.*;
import entorno.*;
public class casa {
    
    private Image img;
    private double x;
    private double y;
    private double angulo;


    public casa(int x, int y){

        this.x = x ;
        this.y = y;
        img = Herramientas.cargarImagen("juego/images/casalule.png");
  
    }

    public void dibujarse(Entorno e)
	{
        //entorno.dibujarRectangulo(this.x  + 5, this.y  + 20, 250, 150, this.angulo, Color.yellow);
		e.dibujarImagen(img, this.x, this.y, this.angulo, 1);
        
	}

    public double getX(){

        return this.x;


    }

    
    public double getY(){

        return this.y;


    }

    
}
